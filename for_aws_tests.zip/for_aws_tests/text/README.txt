It is a picture of a cat.

He has bad habits. And 

some people
* thought *
that
he
was too
intense
